import pandas as pd
import matplotlib.pyplot as plt

#opens data file
df = pd.read_csv("sleepvsgpa.csv")

#plot a scatter plot with the x axis as hours of sleep and y as GPA
df.plot(kind='scatter',x='Hrs of Sleep',y='GPA',)

#set axis labels
plt.xlabel('Average Amount of Hours Slept Per Night')
plt.ylabel('GPA')

#set graph title
plt.title('Is the Amount of Sleep You Get Per Night Indicative of GPA?')

#set background color to pink
plt.rcParams['axes.facecolor'] = 'pink'

#show graph
plt.show()