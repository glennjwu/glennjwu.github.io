import pandas as pd
import matplotlib.pyplot as plt

#opens data file
df = pd.read_csv("sleepvsgpa.csv")

#plot a scatter plot of x as sleep and y as GPA
df.plot(kind='scatter',x='x',y='y',)

#set axis labels
plt.xlabel('Average Amount of Hours Slept')
plt.ylabel('Average GPA')

#set graph title
plt.title('Is the Amount of Sleep You Get Indicative of GPA?')

#show graph
plt.show()